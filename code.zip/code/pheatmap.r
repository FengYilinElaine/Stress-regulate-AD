library(DESeq2)
library(dplyr)
setwd('/home/yfcheng/Desktop/FYL_data/data/T2')
count <- read.table('T2_data.txt',header=T,row.names=1)
meta  <- read.table('T2_meta.txt' ,  header=T,row.names=1)
count <- select(count, c(-6))

head(count)
colnames((count))
meta <-slice(meta,c(-6))
meta
all(colnames(count) == rownames(meta))
head(count)
count_ec <- select(count,c(-4,-5,-7))
meta_ec <- slice(meta, c(-4,-5,-7))


T2_dds_ec <- DESeqDataSetFromMatrix(countData = count_ec, colData = meta_ec, design = ~ sampletype)
library(RColorBrewer)
T2_dds_ec <- estimateSizeFactors((T2_dds_ec))
sizeFactors(T2_dds_ec)
normalized_T2_dds_ec <- counts(T2_dds_ec,normalize=TRUE)
head(normalized_T2_dds_ec)


select_gene_ec = c('Serpina1e', 'Ahsg', 'Serpina1c', 'Itih4', 'F2', 'Kng1', 'Serpina3k', 'Fga', 'Slc6a3',
                  'Ppbp', 'Ido1', 'Ighv3-6', 'Elane', 'Fpr2', 'Ighg1', 'Prg2', 'Ighg2b', 'Igha', 'Ccr1'
)

select_gene_eh = c('Igkv1-117', 'Igkv12-44', 'Igkv17-127', 'Ighg1', 'Igkv15-103', 'Igkv4-59', 'Ighg2b', 'Apob', 'Apoa1', 'S100a8', 'Ager', 'Apoa2', 'S100a9',
                   'Aff2', 'Ghsr', 'Chrna7', 'Chat', 'Gabrb2', 'Wnt2b', 'Kcna1', 'Trpc5', 'Igf2', 'Irs1')

select_gene_hc = c('Slc6a3', 'Atm', 'Gabrb2', 'Chrna7', 'Igf2', 'Th', 'Dnah11', 'Irs1', 'Aff2',
                    'Ighg1','Igha', 'Ighg2b', 'S100a8', 'Il1b', 'Igkc', 'S100a9', 'Lst1', 'Mt3', 'Ccl12')


heat_colors <- brewer.pal(6, "YlOrRd")
myColorPalette2<-c("#125ba2", "#135da4", "#1661a7", "#1864aa", "#1967ad", 
                   "#1c6ab0", "#1f6db1", "#2372b4", "#2675b6", "#2a79b8", "#2e7ebb", "#3181bc", "#3685bf", "#3888c1", "#3d8dc3", 
                   "#4090c5", "#4794c7", "#4c98c9", "#539dcb", "#5ba1ce", "#60a5d0", "#67aad2", "#6cadd4", "#74b2d6", "#79b5d8", 
                   "#81badb", "#8bbfde", "#99c7e2", "#a8d0e6", "#b2d5e9", "#c1dded", "#cbe3f0", "#daebf4", "#e4f0f7", "#f3f8fb", 
                   "#fffefd", "#fff8f5", "#feefe9", "#fee9e1", "#fee0d4", "#fedacc", "#fdd1c0", "#fdcbb8", "#fdc2ac", "#fcb9a0", 
                   "#fcb398", "#fcab8f", "#fca68a", "#fc9e82", "#fc997c", "#fc9174", "#fc8c6e", "#fb8466", "#fb7d5d", "#fb7758", 
                   "#fb7050", "#f96a4d", "#f66348", "#f45e45", "#f15640", "#ee4e3b", "#ec4937", "#ea4133", "#e83c2f", "#e5342a", 
                   "#e32f27", "#dd2c25", "#d92924", "#d32622", "#cd2220")

norm_sig_ec <- normalized_T2_dds_ec[select_gene_ec,]

T2_dge_pm_ec <- pheatmap(log2(norm_sig_ec+1), 
    color = myColorPalette2,
    #color = heat_colors,
    #show_rownames = F,
    annotation = meta_ec, 
    border_color = "gray25", 
    fontsize = 10, 
    scale = "row", 
    fontsize_row = 10, 
   
    height = 20)
T2_dge_pm_ec
ggsave('/home/yfcheng/Desktop/FYL_data/process_data/T2_res/T2_dge_pm_ec.svg', T2_dge_pm_ec)
ggsave('/home/yfcheng/Desktop/FYL_data/process_data/T2_res/T2_dge_pm_ec.png', T2_dge_pm_ec)


count_hc <- select(count,c(-1,-2,-8))
meta_hc <- slice(meta, c(-1,-2,-8))


T2_dds_hc <- DESeqDataSetFromMatrix(countData = count_hc, colData = meta_hc, design = ~ sampletype)
library(RColorBrewer)
T2_dds_hc <- estimateSizeFactors((T2_dds_hc))
sizeFactors(T2_dds_hc)
normalized_T2_dds_hc <- counts(T2_dds_hc,normalize=TRUE)
head(normalized_T2_dds_hc)

norm_sig_hc <- normalized_T2_dds_hc[select_gene_hc,]

T2_dge_pm_hc <- pheatmap(log2(norm_sig_hc+1), 
    color = myColorPalette2,
    #color = heat_colors,
    #show_rownames = F,
    annotation = meta_hc, 
    border_color = "gray25", 
    fontsize = 10, 
    scale = "row", 
    fontsize_row = 10, 
   
    height = 20)
T2_dge_pm_hc
ggsave('/home/yfcheng/Desktop/FYL_data/process_data/T2_res/T2_dge_pm_hc.svg', T2_dge_pm_hc)
ggsave('/home/yfcheng/Desktop/FYL_data/process_data/T2_res/T2_dge_pm_hc.png', T2_dge_pm_hc)

head(count)
count_he <- select(count,c(-3,-6))
meta_he <- slice(meta, c(-3,-6))


T2_dds_he <- DESeqDataSetFromMatrix(countData = count_he, colData = meta_he, design = ~ sampletype)
library(RColorBrewer)
T2_dds_he <- estimateSizeFactors((T2_dds_he))
sizeFactors(T2_dds_he)
normalized_T2_dds_he <- counts(T2_dds_he,normalize=TRUE)
head(normalized_T2_dds_he)

norm_sig_he <- normalized_T2_dds_he[select_gene_eh,]

T2_dge_pm_he <- pheatmap(log2(norm_sig_he+1), 
    color = myColorPalette2,
    #color = heat_colors,
    #show_rownames = F,
    annotation = meta_he, 
    border_color = "gray25", 
    fontsize = 10, 
    scale = "row", 
    fontsize_row = 10, 
   
    height = 20)
T2_dge_pm_he
ggsave('/home/yfcheng/Desktop/FYL_data/process_data/T2_res/T2_dge_pm_he.svg', T2_dge_pm_he)
ggsave('/home/yfcheng/Desktop/FYL_data/process_data/T2_res/T2_dge_pm_he.png', T2_dge_pm_he)
